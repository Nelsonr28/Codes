#include <iostream>

using namespace std;

char (char array [], int tam)
{
  if
  {

  }
}
