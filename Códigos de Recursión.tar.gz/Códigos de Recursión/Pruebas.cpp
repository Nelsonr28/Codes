#include <iostream>

using namespace std;

int main ()
{
  int s;
  for (int i = 0; i < 4; i++)
    {
      s += 3;
    }
    cout << s << endl;
}
