#include <iostream>

using namespace std;

int Permutar (char arr [], char arrayPermu [], int ind, int tam)
{
  if ()
}
